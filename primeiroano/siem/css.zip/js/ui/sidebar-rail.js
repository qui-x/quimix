/* ═══════════════════════════════════════════════════════════════
   CAMADA: INTERFACE  ·  js/ui/sidebar-rail.js
   ───────────────────────────────────────────────────────────────
   TRILHO RECOLHÍVEL DAS SIDEBARS — versão única para as três séries.

   Recolhida, a sidebar sai do fluxo e vira um trilho de 56px só com
   os ícones dos seus painéis. Clicar num ícone traz aquele card de
   volta FLUTUANDO por cima do canvas — e, se o card for de um modo,
   ativa o modo junto.

   POR QUE FLUTUANTE, E NÃO REABRIR A SIDEBAR
   Reabrir no fluxo encolheria o canvas, disparando o recálculo de
   tamanho. Em parte dos simuladores isso RECOMEÇA a simulação (no
   SIMA o _resize() termina em sim.rebuild()). Flutuando, a sidebar é
   position:absolute e não ocupa espaço de flex: o canvas não muda de
   tamanho, nada é remedido, nada é reconstruído. Consultar um painel
   com a simulação rodando fica gratuito.

   O QUE VARIA ENTRE AS FAMÍLIAS, E COMO É ABSORVIDO
   1. Onde moram os cards de modo
        1º ano  → filhos diretos de #sidebar-left
        2º/3º   → dentro de <div id="model-list">
      Resolvido varrendo QUALQUER .panel descendente da sidebar e
      escondendo os irmãos nível a nível até a raiz (marcaCaminho).
   2. Como se ativa um modo
        1º ano  → <button data-model="bohr">
        2º/3º   → <button class="mode-activate-btn"> com listener de
                  fechamento, sem atributo que diga o modo
      Resolvido usando o denominador comum: o botão .mode-activate-btn
      e o aria-pressed que as duas famílias já mantêm. Nunca clicamos
      num botão já pressionado — os dois lados tratam o clique no modo
      ativo como DESATIVAR, e o ícone do trilho não pode desligar nada.
   3. Como o canvas descobre que mudou de tamanho
        2º/3º   → ResizeObserver no .canvas-wrap (pega sozinho)
        1º ano  → só window.resize
      Resolvido disparando um window.resize sintético ao fim da
      transição de recolher/expandir. Para quem tem ResizeObserver é
      redundante e inofensivo; para quem não tem, é o que faz funcionar.
      Nenhuma referência à instância da app é necessária — o que
      importa, porque no 2º ano ela nem é guardada em lugar nenhum
      (`new SICQ.App(...)` e pronto).

   CONFIGURAÇÃO
   Lê window.RAIL_CFG, escrito no HTML logo antes deste arquivo:
     { id: 'cinetica', bp: 1100 }
   `id`  prefixa a chave de localStorage que guarda a escolha.
   `bp`  é o breakpoint mobile daquele CSS: abaixo (e em) `bp` este
         módulo sai de cena e o layout mobile da casa assume inteiro.

   O QUE ELE NÃO FAZ
   · Não toca no mobile. Todo o CSS mora em @media (min-width: bp+1px)
     e o script sai pela porta dos fundos em telas estreitas.
   · Não move nenhum nó do DOM. Quem muda de posição é a sidebar toda,
     por CSS; os painéis ficam onde estavam e todos os listeners
     ligados na inicialização continuam válidos.
   · Não duplica ícone: cada botão clona o .panel-icon do cabeçalho.
═══════════════════════════════════════════════════════════════ */

'use strict';

(function () {
  var CFG = window.RAIL_CFG || {};
  var SIM_ID = CFG.id || 'sim';
  var BP = CFG.bp || 1100; // largura em que o layout mobile assume

  /* Botão que ATIVA o modo dono do card. Cada família nomeou o seu:
       1º ano SIMA/SIME ....... .mode-activate-btn  (+ data-model /
                                 data-modulo-ativar)
       1º ano SILQ/SIFI ....... .bond-mode-btn      (data-bond-type /
                                 data-module)
       2º/3º ano .............. .mode-activate-btn  (criado em
                                 _buildModes(), sem atributo de modo)
     O que TODAS têm em comum é o aria-pressed, que é o que o trilho
     usa para saber se já está ativo e para espelhar o ícone. Lista
     explícita de propósito: pegar "qualquer botão com aria-pressed"
     acertaria alvos errados (toggles de exibição, por exemplo). */
  var SEL_ATIVAR = '.mode-activate-btn, .bond-mode-btn, [data-model]';

  function initSidebarRail() {
    var config = [
      { lado: 'left',  sidebar: document.getElementById('sidebar-left'),
        rotulo: 'menus e modos',     fechaNoCanvas: true  },
      { lado: 'right', sidebar: document.getElementById('sidebar-right'),
        rotulo: 'controles e dados', fechaNoCanvas: false }
    ].filter(function (c) { return c.sidebar; });
    if (!config.length) return;

    var abertoAgora = null;

    /* ── helpers ───────────────────────────────────────────────── */

    function ehDesktop() { return window.innerWidth > BP; }
    function chaveDe(lado) { return SIM_ID + '-rail-' + lado; }

    /* RECOLHIDA É O PADRÃO: sem nada salvo, as duas nascem como trilho
       e o canvas abre com quase toda a largura da janela. */
    function lerEstado(lado) {
      try {
        var v = localStorage.getItem(chaveDe(lado));
        return v === null ? true : v === 'recolhida';
      } catch (e) { return true; }
    }
    function salvarEstado(lado, recolhida) {
      try { localStorage.setItem(chaveDe(lado), recolhida ? 'recolhida' : 'aberta'); }
      catch (e) { /* sem persistência, funciona só na sessão */ }
    }

    function espera() {
      return document.body.classList.contains('reduce-motion') ? 0 : 200;
    }

    /* Avisa o simulador que a largura útil mudou. window.resize serve
       às duas famílias: quem tem ResizeObserver já reagiu antes e
       ignora; quem não tem depende disto. */
    function remedirCanvas() {
      window.dispatchEvent(new Event('resize'));
    }

    function anunciar(texto) {
      if (typeof window.announce === 'function') { window.announce(texto); return; }
      var vivo = document.getElementById('sr-live');
      if (vivo) vivo.textContent = texto;
    }

    /* Todos os .panel da sidebar que tenham cabeçalho, em qualquer
       profundidade — cobre tanto o 1º ano (filhos diretos) quanto o
       2º/3º (dentro de #model-list). */
    function paineisDe(sidebar) {
      return Array.prototype.filter.call(
        sidebar.querySelectorAll('.panel'),
        function (p) { return !!p.querySelector('.panel-header'); }
      );
    }

    /* ── montagem do trilho ────────────────────────────────────── */

    var CHEVRON_ESQ = '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" ' +
      'stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
    var CHEVRON_DIR = '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" ' +
      'stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';

    /* Copia o desenho do .panel-icon do cabeçalho para o botão do
       trilho — sem criar um segundo catálogo de SVG para manter em dia.
       DUAS ARMADILHAS:
       1. Nem todo simulador tem ícone: o sifi usa
          <span class="panel-icon" data-icon="modulo1"></span>, um
          marcador VAZIO que o próprio app preenche depois. Quando o
          trilho monta, ele pode ainda estar em branco.
       2. Um ícone que chega depois precisa aparecer no trilho.
       Daí a inicial do nome como reserva (um trilho de quadrados vazios
       é pior que um de letras) e o re-preenchimento por observador
       logo abaixo, que troca a letra pelo desenho assim que ele existe. */
    function preencherIcone(b) {
      var span = b.querySelector('.rail-ico');
      if (!span) return;
      var conteudo = b._icone ? b._icone.innerHTML.trim() : '';
      if (conteudo) {
        if (span.innerHTML.trim() !== conteudo) span.innerHTML = conteudo;
        span.classList.remove('rail-ico--letra');
      } else if (!span.classList.contains('rail-ico--letra')) {
        span.textContent = b._inicial || '?';
        span.classList.add('rail-ico--letra');
      }
    }

    function criarTrilho(cfg) {
      var trilho = document.createElement('div');
      trilho.className = 'rail rail--' + cfg.lado;
      trilho.id = 'rail-' + cfg.lado;
      trilho.setAttribute('role', 'toolbar');
      trilho.setAttribute('aria-orientation', 'vertical');
      trilho.setAttribute('aria-label', 'Atalhos — ' + cfg.rotulo);
      trilho.hidden = true;

      var fixar = document.createElement('button');
      fixar.type = 'button';
      fixar.className = 'rail-btn rail-btn--expand';
      fixar.innerHTML = (cfg.lado === 'left' ? CHEVRON_DIR : CHEVRON_ESQ) +
        '<span class="rail-tip">Fixar painel de ' + cfg.rotulo + '</span>';
      fixar.setAttribute('aria-label', 'Fixar painel de ' + cfg.rotulo);
      fixar.addEventListener('click', function () { recolher(cfg, false); });
      trilho.appendChild(fixar);

      var sep = document.createElement('div');
      sep.className = 'rail-sep';
      sep.setAttribute('aria-hidden', 'true');
      trilho.appendChild(sep);

      paineisDe(cfg.sidebar).forEach(function (painel, i) {
        var cab = painel.querySelector('.panel-header');
        var icone = cab.querySelector('.panel-icon');
        var rotulo = cab.querySelector('.panel-label');
        var etiqueta = cab.querySelector('.panel-badge');
        var nome = rotulo ? rotulo.textContent.trim() : 'Painel ' + (i + 1);

        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'rail-btn';
        b.setAttribute('aria-label', nome);
        b.setAttribute('aria-expanded', 'false');

        var span = document.createElement('span');
        span.className = 'rail-ico';
        span.setAttribute('aria-hidden', 'true');
        b.appendChild(span);
        b._icone = icone;   // nó vivo do cabeçalho, para re-sincronizar
        b._inicial = nome.charAt(0).toUpperCase();
        preencherIcone(b);

        var tip = document.createElement('span');
        tip.className = 'rail-tip';
        tip.textContent = etiqueta ? nome + ' · ' + etiqueta.textContent.trim() : nome;
        b.appendChild(tip);

        b._painel = painel; // casa botão↔painel por REFERÊNCIA: metade
                            // dos painéis não tem atributo id
        b.addEventListener('click', function () { alternarFlutuante(cfg, painel, b); });
        trilho.appendChild(b);
      });
      return trilho;
    }

    /* ── recolher / fixar: muda a largura do canvas ─────────────── */

    function recolher(cfg, deveRecolher) {
      if (!ehDesktop()) return;
      fecharFlutuante();
      limparSolo(cfg);
      cfg.sidebar.classList.toggle('is-collapsed', deveRecolher);
      cfg.trilho.hidden = !deveRecolher;
      if (cfg.botaoRecolher) {
        cfg.botaoRecolher.setAttribute('aria-expanded', String(!deveRecolher));
        cfg.botaoRecolher.setAttribute('aria-label',
          (deveRecolher ? 'Fixar' : 'Recolher') + ' painel de ' + cfg.rotulo);
      }
      salvarEstado(cfg.lado, deveRecolher);
      anunciar('Painel de ' + cfg.rotulo + (deveRecolher ? ' recolhido.' : ' fixado.'));
      window.setTimeout(remedirCanvas, espera());
    }

    /* ── flutuante: NÃO muda a largura do canvas ────────────────── */

    /* Gerações POR SIDEBAR. A limpeza do formato compacto é adiada até
       o fim do fade (ver comentário em fecharFlutuante); sem um
       carimbo por sidebar, abrir um card na direita cancelaria a
       limpeza pendente da esquerda, que ficaria compacta para sempre. */

    function fecharFlutuante() {
      if (!abertoAgora) return;
      var cfg = abertoAgora.cfg;
      cfg.sidebar.classList.remove('is-floating');

      /* NÃO limpar o compacto agora. Tirar .is-floating apenas INICIA o
         fade; a sidebar segue visível por ~180ms. Se o compacto saísse
         no primeiro quadro, todos os cards voltariam e a sidebar
         esticaria de topo a base ainda à vista — era a sidebar inteira
         piscando ao fechar. O .has-solo sai quando já está invisível. */
      var g = cfg.geracao = (cfg.geracao || 0) + 1;
      window.setTimeout(function () {
        if (g === cfg.geracao) limparSolo(cfg);
      }, espera());

      Array.prototype.forEach.call(
        cfg.trilho.querySelectorAll('.rail-btn[aria-expanded]'),
        function (b) { b.setAttribute('aria-expanded', 'false'); });
      abertoAgora = null;
      document.removeEventListener('keydown', aoTeclar, true);
    }

    function aoTeclar(e) {
      if (e.key !== 'Escape' || !abertoAgora) return;
      var alvo = abertoAgora.botao;
      fecharFlutuante();
      if (alvo) alvo.focus();
    }

    /* Ativa o modo dono do card delegando o clique para o botão que já
       existe dentro dele — mesmo caminho da barra de modos mobile.
       Som, troca de painéis, aria-pressed e desenho vêm de graça.
       A guarda do aria-pressed é obrigatória: nas duas famílias clicar
       no modo JÁ ativo desativa, e um ícone de navegação não pode
       apagar a simulação de quem só queria reler o card. */
    function ativarSeForModo(painel) {
      var btn = painel.querySelector(SEL_ATIVAR);
      if (!btn) return false;
      if (btn.getAttribute('aria-pressed') === 'true') return false;
      btn.click();
      return true;
    }

    /* Esconde os irmãos do painel nível a nível, subindo até a sidebar.
       É o que permite funcionar tanto com o card solto na sidebar (1º
       ano) quanto embrulhado em #model-list (2º/3º) sem saber de qual
       família se trata. */
    function mostrarSozinho(cfg, painel) {
      cfg.geracao = (cfg.geracao || 0) + 1; // invalida limpeza pendente
      limparSolo(cfg);
      var no = painel;
      while (no && no !== cfg.sidebar && no.parentNode) {
        Array.prototype.forEach.call(no.parentNode.children, function (irmao) {
          if (irmao !== no) irmao.classList.add('rail-oculto');
        });
        no = no.parentNode;
      }
      painel.classList.add('is-solo');
      /* a marca do compacto vive na SIDEBAR, não em .is-floating: é o
         que faz o formato sobreviver aos 180ms de fade ao fechar */
      cfg.sidebar.classList.add('has-solo');

      var cab = painel.querySelector('.panel-header');
      var corpo = painel.querySelector('.panel-body');
      if (cab) cab.setAttribute('aria-expanded', 'true');
      if (corpo) corpo.classList.remove('collapsed');
    }

    function limparSolo(cfg) {
      cfg.sidebar.classList.remove('has-solo');
      Array.prototype.forEach.call(
        cfg.sidebar.querySelectorAll('.rail-oculto, .is-solo'),
        function (el) { el.classList.remove('rail-oculto', 'is-solo'); });
    }

    function alternarFlutuante(cfg, painel, botao) {
      var jaAberto = abertoAgora && abertoAgora.cfg === cfg &&
                     abertoAgora.painel === painel;
      fecharFlutuante();
      if (jaAberto) return;

      /* Ordem: ativar PRIMEIRO, expandir DEPOIS — as duas famílias
         recolhem o card logo após ativar, para liberar o canvas. */
      ativarSeForModo(painel);
      mostrarSozinho(cfg, painel);
      sincronizarAtivo();
      sincronizarVisiveis(); // ativar um modo muda quais painéis existem

      cfg.sidebar.classList.add('is-floating');
      botao.setAttribute('aria-expanded', 'true');
      abertoAgora = { cfg: cfg, painel: painel, botao: botao };

      if (painel.scrollIntoView) painel.scrollIntoView({ block: 'start', behavior: 'auto' });
      var cab = painel.querySelector('.panel-header');
      if (cab) cab.focus({ preventScroll: true });
      document.addEventListener('keydown', aoTeclar, true);
    }

    /* ── espelhos do estado do app ─────────────────────────────── */

    /* Com a sidebar recolhida por padrão, o trilho é o único indicador
       de "onde eu estou": sem esta marca, o aluno ativa um modo, fecha
       o card e não sobra nada na tela dizendo qual modo está rodando. */
    function sincronizarAtivo() {
      config.forEach(function (cfg) {
        Array.prototype.forEach.call(cfg.trilho.querySelectorAll('.rail-btn'),
          function (b) {
            if (!b._painel) return;
            var alvo = b._painel.querySelector(SEL_ATIVAR);
            b.classList.toggle('is-active',
              !!alvo && alvo.getAttribute('aria-pressed') === 'true');
          });
      });
    }

    /* Painéis que entram e saem conforme o estado do app precisam
       entrar e sair do trilho junto: no 2º/3º ano os .panel[data-owner]
       trocam a cada modo; no 1º ano a Tabela Periódica e os Dados do
       Elemento só existem com algum modelo ativo.
       Casa por REFERÊNCIA (b._painel) e não por id: vários desses
       painéis não têm atributo id — só o cabeçalho tem. Filtrar por
       .panel[id] foi exatamente o bug que sumiu com o ícone da Tabela
       Periódica e nunca o devolveu. */
    function sincronizarVisiveis() {
      config.forEach(function (cfg) {
        Array.prototype.forEach.call(cfg.trilho.querySelectorAll('.rail-btn'),
          function (b) {
            if (!b._painel) return;
            b.hidden = b._painel.hasAttribute('hidden');
          });
        if (abertoAgora && abertoAgora.cfg === cfg &&
            abertoAgora.painel.hasAttribute('hidden')) fecharFlutuante();
      });
    }

    /* ── montagem final ────────────────────────────────────────── */

    config.forEach(function (cfg) {
      cfg.trilho = criarTrilho(cfg);
      /* O trilho entra ao lado da PRÓPRIA sidebar, não dentro de um
         container fixo. Em silq e sifi o #main-content é o canvas em
         si (<main class="canvas-area">), e as sidebars são irmãs dele;
         no sie não existe #main-content nem .app-main. Ancorar no pai
         real da sidebar funciona nas três estruturas sem saber de qual
         se trata. O pai também vira a referência do flutuante
         absoluto — daí a classe .rail-host. */
      var hosp = cfg.sidebar.parentNode;
      hosp.classList.add('rail-host');
      if (cfg.lado === 'left') hosp.insertBefore(cfg.trilho, cfg.sidebar);
      else hosp.insertBefore(cfg.trilho, cfg.sidebar.nextSibling);

      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'rail-toggle';
      b.dataset.railToggle = cfg.lado;
      b.innerHTML = cfg.lado === 'left' ? CHEVRON_ESQ : CHEVRON_DIR;
      b.setAttribute('aria-controls', cfg.sidebar.id);
      b.setAttribute('aria-expanded', 'true');
      b.setAttribute('aria-label', 'Recolher painel de ' + cfg.rotulo);
      b.addEventListener('click', function () {
        recolher(cfg, !cfg.sidebar.classList.contains('is-collapsed'));
      });
      cfg.botaoRecolher = b;
      cfg.sidebar.insertBefore(b, cfg.sidebar.firstChild);

      if (ehDesktop() && lerEstado(cfg.lado)) recolher(cfg, true);
    });

    /* ── tour guiado ────────────────────────────────────────────
       Todo tour do projeto destaca elementos que moram dentro das
       sidebars. Com elas recolhidas, o coachmark mede o retângulo de
       um elemento invisível e o holofote cai no vazio.
       Enquanto o tour roda, as duas ficam fixas; ao terminar, voltam
       ao que o aluno tinha escolhido. Nada é salvo no meio — a
       preferência dele não muda por ter assistido ao tour. */
    var suspenso = null;
    document.addEventListener('coachmark:inicio', function () {
      if (!ehDesktop() || suspenso) return;
      fecharFlutuante();
      suspenso = {};
      config.forEach(function (cfg) {
        suspenso[cfg.lado] = cfg.sidebar.classList.contains('is-collapsed');
        if (!suspenso[cfg.lado]) return;
        limparSolo(cfg);
        cfg.sidebar.classList.remove('is-collapsed');
        cfg.trilho.hidden = true;
      });
      window.setTimeout(remedirCanvas, espera());
    });
    document.addEventListener('coachmark:fim', function () {
      if (!suspenso) return;
      var estava = suspenso; suspenso = null;
      if (!ehDesktop()) return;
      config.forEach(function (cfg) {
        if (!estava[cfg.lado]) return;
        cfg.sidebar.classList.add('is-collapsed');
        cfg.trilho.hidden = false;
      });
      window.setTimeout(remedirCanvas, espera());
    });

    var canvas = document.getElementById('sim-canvas') ||
                 document.querySelector('.canvas-wrap canvas');
    if (canvas) {
      canvas.addEventListener('pointerdown', function () {
        if (abertoAgora && abertoAgora.cfg.fechaNoCanvas) fecharFlutuante();
      });
    }

    /* Ao cruzar para o mobile desfaz tudo — o layout de baixo do
       breakpoint (bottom sheet + barra de modos) assume sozinho. Ao
       voltar, restaura o que estava salvo. */
    var eraDesktop = ehDesktop();
    window.addEventListener('resize', function () {
      var agora = ehDesktop();
      if (agora === eraDesktop) return;
      eraDesktop = agora;
      fecharFlutuante();
      config.forEach(function (cfg) {
        limparSolo(cfg);
        if (!agora) {
          cfg.sidebar.classList.remove('is-collapsed');
          cfg.trilho.hidden = true;
        } else if (lerEstado(cfg.lado)) {
          recolher(cfg, true);
        }
      });
    });

    if (typeof MutationObserver !== 'undefined') {
      var vigia = new MutationObserver(function () {
        sincronizarVisiveis();
        sincronizarAtivo();
      });
      config.forEach(function (cfg) {
        paineisDe(cfg.sidebar).forEach(function (p) {
          vigia.observe(p, { attributes: true, attributeFilter: ['hidden'] });
          var alvo = p.querySelector(SEL_ATIVAR);
          if (alvo) vigia.observe(alvo, { attributes: true, attributeFilter: ['aria-pressed'] });
        });
        /* ícones preenchidos pelo app depois da montagem (sifi) */
        var vigiaIcone = new MutationObserver(function () {
          Array.prototype.forEach.call(cfg.trilho.querySelectorAll('.rail-btn'),
            function (b) { if (b._icone) preencherIcone(b); });
        });
        Array.prototype.forEach.call(cfg.trilho.querySelectorAll('.rail-btn'),
          function (b) {
            if (b._icone) vigiaIcone.observe(b._icone, { childList: true, subtree: true });
          });
      });
      sincronizarVisiveis();
      sincronizarAtivo();
    }
  }

  window.addEventListener('DOMContentLoaded', initSidebarRail);
})();
