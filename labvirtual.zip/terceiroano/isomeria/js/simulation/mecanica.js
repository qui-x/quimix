/* ═══════════════════════════════════════════════════════════════
   CAMADA: SIMULAÇÃO
   ARQUIVO: js/simulation/mecanica.js (SIIS)
   ───────────────────────────────────────────────────────────────
   O ROTEADOR do SIIS: repassa ao módulo ativo o toque, as setas, os
   controles, as ações, o desenho e os resultados.
     Módulo 1 — Isomeria Constitucional ... bancada-isomeria.js
     Módulo 2 — Isomeria Geométrica ....... bancada-geometrica.js (herda a bancada)
   Os Módulos 2 (Geométrica) e 3 (Óptica) entram conforme ficam prontos.
═══════════════════════════════════════════════════════════════ */

'use strict';

class Mech {
  constructor(D) {
    this.D = D;
    this.modo = 'constitucional';
    this.bi = new BancadaIsomeria(D);           // Módulo 1
    this.bg = new BancadaGeometrica(D);         // Módulo 2
  }
  _ativo() { return this.modo === 'geometrica' ? this.bg : this.bi; }
  /* a lista das representações dos cartões: as seis do Módulo 1 do SIQC (representacoes.js) */
  build() {
    fillOptGrid('bi-vista-grid', Q3.Representacoes.VISTAS.map(v => ({
      value: v.id, nome: v.nome, extra: v.extra,
      aria: v.nome + (v.tresD ? ', em três dimensões' : ''),
    })), 'completa');
  }
  /* Ativar um módulo DESATIVA E LIMPA o anterior (regra do projeto);
     desligar o módulo sem ativar outro também o limpa. */
  setMode(id) {
    this.modo = id;
    const novo = id === 'constitucional' ? this.bi : id === 'geometrica' ? this.bg : null;
    [this.bi, this.bg].forEach(m => { if (m !== novo && m.ativo) m.desativar(); });
    if (this._anterior && this._anterior !== novo) this._anterior.reiniciar();
    if (novo) novo.ativar();
    this._anterior = novo;
  }
  setParam(k, v) {
    // a representação dos cartões vale para os DOIS módulos (a escolha continua ao trocar de módulo)
    if (k === 'bi-vista') { this.bi.vista = v; this.bg.vista = v; return this._ativo().mudarVista(v); }
    // controles do editor herdado do SIQC (o desenho de um espaço)
    if (['elemento', 'ferramenta', 'cunhaTipo', 'tensao', 'vista'].indexOf(k) >= 0) return this._ativo().editor.param(k, v);
    return {};
  }
  action(name) {
    if (name.indexOf('bi-') === 0) return this._ativo().acao(name);      // os painéis da bancada são dos dois módulos
    if (name.indexOf('bg-') === 0) return this.bg.acao(name);
    if (name.indexOf('cad-') === 0) return this._ativo().editor.acao(name);
    return false;
  }
  onCanvasClick(x, y) { return this._ativo().tocar(x, y); }
  onArrow(dx, dy) { return this._ativo().navegar(dx, dy); }
  update(dt) { this._ativo().atualizar(dt); }
  draw(ctx, W, H) { this._ativo().desenhar(ctx, W, H); }
  getResults() { return this._ativo().resultados(); }
  getOverlay() { return this._ativo().overlay(); }
}
