/* ═══════════════════════════════════════════════════════════════
   CAMADA: SIMULAÇÃO
   ARQUIVO: js/simulation/mecanica.js
   ───────────────────────────────────────────────────────────────
   A classe Mech: os modos, os parâmetros, a química e o que vai para o canvas. É o coração do simulador.

   Extraído de scriptreacoes.js na refatoração para a estrutura de
   pastas do SIMA. A divisão é literal: o escopo continua global e
   as tags <script> continuam compartilhando-o, então nenhuma
   referência mudou de nome. O que mudou é onde cada coisa mora.

   Ordem de carga (definida em index.html): a11y → core → data →
   ui → simulation → init. Quebrar essa ordem quebra o simulador.
═══════════════════════════════════════════════════════════════ */

'use strict';

class Mech {
  constructor(D) {
    this.D = D;
    this.modo = 'adicao';
    this.t = 0;

    this.adicao = D.ADICOES[0];
    this.subst = D.SUBSTITUICOES[0];
    // modo 3 — combustão
    this.nc = 3;
    this.tipo = D.COMBUSTAO_TIPOS[0];
  }

  build() {
    fillOptGrid('ad-grid', this.D.ADICOES.map(a => ({
      value: a.id, nome: a.nome, dot: a.dot, extra: a.reagente,
      aria: `${a.nome} com ${a.reagente}, produto ${a.produto}`,
    })), this.adicao.id);

    fillOptGrid('sub-grid', this.D.SUBSTITUICOES.map(s => ({
      value: s.id, nome: s.nome, dot: s.dot, extra: s.reagente,
      aria: `${s.nome}, substrato ${s.substrato}, reagente ${s.reagente}`,
    })), this.subst.id);
  }

  setMode(id) { this.modo = id; this.t = 0; }

  setParam(k, v) {
    switch (k) {
      case 'adr': {
        this.adicao = this.D.ADICOES.find(a => a.id === v) || this.adicao;
        return { say: `${this.adicao.nome} com ${this.adicao.reagente}. Produto: ${this.adicao.produto}. ${this.adicao.regra}.` };
      }
      case 'subr': {
        this.subst = this.D.SUBSTITUICOES.find(s => s.id === v) || this.subst;
        return { say: `${this.subst.nome}. Equação: ${this.subst.eq}. Mecanismo ${this.subst.mecanismo}.` };
      }
      case 'combn': {
        this.nc = clamp(Math.round(v), 1, 10);
        const e = this._equacao();
        return { say: `Alcano com ${this.nc} carbonos. Equação: ${e.texto}.` };
      }
      case 'combtipo': {
        this.tipo = this.D.COMBUSTAO_TIPOS.find(t => t.id === v) || this.tipo;
        return { say: `Combustão ${this.tipo.nome}. ${this.tipo.nota}.` };
      }
    }
    return {};
  }

  action(name) {
    if (name === 'ad-next') {
      const L = this.D.ADICOES;
      this.adicao = L[(L.indexOf(this.adicao) + 1) % L.length];
      this._marcarOpt('ad-grid', this.adicao.id);
      playTone(720, .07, .05);
      announce(`${this.adicao.nome}: ${this.adicao.eq}. ${this.adicao.regra}.`);
    }
    if (name === 'sub-next') {
      const L = this.D.SUBSTITUICOES;
      this.subst = L[(L.indexOf(this.subst) + 1) % L.length];
      this._marcarOpt('sub-grid', this.subst.id);
      playTone(700, .07, .05);
      announce(`${this.subst.nome}: ${this.subst.eq}. Condição: ${this.subst.condicao}.`);
    }
    if (name === 'comb-next') {
      const L = this.D.COMBUSTAO_TIPOS;
      this.tipo = L[(L.indexOf(this.tipo) + 1) % L.length];
      document.querySelectorAll('.seg[data-group="combtipo"] .seg-btn').forEach(b => {
        b.setAttribute('aria-pressed', String(b.dataset.value === this.tipo.id));
      });
      playTone(660, .07, .05);
      const e = this._equacao();
      announce(`Combustão ${this.tipo.nome}. Equação balanceada: ${e.texto}.`);
    }
  }

  _marcarOpt(gridId, value) {
    const grid = document.getElementById(gridId);
    if (!grid) return;
    grid.querySelectorAll('.opt-btn').forEach(b => {
      const on = b.dataset.value === String(value);
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', String(on));
    });
  }

  /* ══════════ balanceamento da combustão ══════════
     Alcano CₙH₂ₙ₊₂. Trabalhamos com o dobro de tudo para não usar
     fração e depois dividimos pelo MDC dos quatro coeficientes.   */
  _equacao() {
    const n = this.nc;
    const H = 2 * n + 2;
    let combustivel = 2, oxigenio, carbonado, agua = H;   // 2 CₙH₂ₙ₊₂ → H₂O = 2·(n+1) = H
    if (this.tipo.id === 'completa') { oxigenio = 3 * n + 1; carbonado = 2 * n; }
    else if (this.tipo.id === 'monoxido') { oxigenio = 2 * n + 1; carbonado = 2 * n; }
    else { oxigenio = n + 1; carbonado = 2 * n; }

    const g = [combustivel, oxigenio, carbonado, agua].reduce((a, b) => mdc(a, b));
    combustivel /= g; oxigenio /= g; carbonado /= g; agua /= g;

    const co = (c) => (c === 1 ? '' : c + ' ');
    const alcano = 'C' + (n > 1 ? subscrito(n) : '') + 'H' + subscrito(H);
    const produto = this.tipo.id === 'completa' ? 'CO₂' : this.tipo.id === 'monoxido' ? 'CO' : 'C(s)';
    const texto = `${co(combustivel)}${alcano} + ${co(oxigenio)}O₂ → ${co(carbonado)}${produto} + ${co(agua)}H₂O`;

    return {
      texto, alcano, produto, combustivel, oxigenio, carbonado, agua, n, H,
      razaoO2: oxigenio / combustivel,
    };
  }

  update(dt) { this.t += dt; }

  draw(ctx, W, H) {
    if (this.modo === 'adicao') this._drawReacao(ctx, W, H, this.adicao, 'adição');
    else if (this.modo === 'substituicao') this._drawReacao(ctx, W, H, this.subst, 'substituição');
    else this._drawCombustao(ctx, W, H);
  }

  _corEl(el) {
    if (el === 'O' || el === 'OH') return cssVar('--accent-warn', '#f87171');
    if (el === 'N' || el.indexOf('N') === 0) return cssVar('--accent-ok', '#4ade80');
    if (el === 'Br' || el === 'Cl') return cssVar('--accent-amber', '#fbbf24');
    if (el === 'H') return cssVar('--scene-b', '#94a3b8');
    if (el.length > 1) return cssVar('--accent-alt', '#38bdf8');
    return cssVar('--scene-a', '#22d3ee');
  }

  /** Desenha uma molécula dentro de uma caixa em pixels. */
  _drawMolBox(ctx, mol, box) {
    const pos = mol.atomos.map(a => ({ x: box.x + a[0] * box.w, y: box.y + a[1] * box.h, el: a[2] }));
    mol.ligacoes.forEach(([i, j, ordem]) => {
      kBond(ctx, pos[i].x, pos[i].y, pos[j].x, pos[j].y, ordem,
        { color: cssVar('--scene-a', '#22d3ee'), width: 2.3, gap: 3.4 });
    });
    pos.forEach(p => {
      const r = 12 + Math.max(0, p.el.length - 1) * 3.2;
      kAtom(ctx, p.x, p.y, r, p.el, { color: this._corEl(p.el), size: p.el.length > 2 ? 9 : 11 });
    });
    return pos;
  }

  /* ══════════ MODOS 1 e 2 — antes → depois ══════════ */
  _drawReacao(ctx, W, H, r, rotuloTipo) {
    kLabel(ctx, r.nome, W / 2, 38, { size: 16, bold: true, align: 'center', color: r.dot });
    kLabel(ctx, `reação de ${rotuloTipo}`, W / 2, 58, { size: 11, align: 'center' });

    const topo = 78, alturaBox = Math.max(90, H - topo - 118);
    const larguraBox = Math.min(W * .34, 260);
    const boxA = { x: W * .5 - larguraBox - 46, y: topo, w: larguraBox, h: alturaBox };
    const boxB = { x: W * .5 + 46, y: topo, w: larguraBox, h: alturaBox };

    this._drawMolBox(ctx, r.antes, boxA);
    this._drawMolBox(ctx, r.depois, boxB);

    const yMeio = topo + alturaBox / 2;
    kArrow(ctx, W * .5 - 36, yMeio, W * .5 + 36, yMeio,
      { color: cssVar('--accent-main', '#22d3ee'), width: 2, head: 9 });
    kLabel(ctx, r.reagente, W * .5, yMeio - 14, { size: 12, bold: true, align: 'center', color: cssVar('--accent-amber', '#fbbf24') });
    kLabel(ctx, r.catalisador || r.condicao || '', W * .5, yMeio + 24, { size: 10, align: 'center', color: cssVar('--text-muted', '#3d566e') });

    kLabel(ctx, 'reagente', boxA.x + boxA.w / 2, topo + alturaBox + 20, { size: 10, align: 'center', color: cssVar('--text-muted', '#3d566e') });
    kLabel(ctx, r.produto, boxB.x + boxB.w / 2, topo + alturaBox + 20, { size: 11, align: 'center', color: r.dot });

    kLabel(ctx, r.eq, W / 2, H - 58, { size: 14, mono: true, align: 'center', color: cssVar('--text-primary', '#ddeaf8') });
    kLabel(ctx, r.regra || r.mecanismo, W / 2, H - 34, { size: 11, align: 'center', color: cssVar('--accent-main', '#22d3ee') });
    kLabel(ctx, r.nota, W / 2, H - 14, { size: 10, align: 'center', color: cssVar('--text-muted', '#3d566e') });
  }

  /* ══════════ MODO 3 — combustão ══════════ */
  _drawCombustao(ctx, W, H) {
    const e = this._equacao();
    kLabel(ctx, `Combustão ${this.tipo.nome}`, W / 2, 40,
      { size: 16, bold: true, align: 'center', color: this.tipo.dot });
    kLabel(ctx, `produtos: ${this.tipo.produto}`, W / 2, 60, { size: 11, align: 'center' });

    // Equação balanceada, grande e centralizada
    kLabel(ctx, e.texto, W / 2, H / 2 - 26,
      { size: Math.max(13, Math.min(20, W / 34)), mono: true, bold: true, align: 'center', color: cssVar('--text-primary', '#ddeaf8') });

    // Barra proporcional de O₂ por molécula de combustível
    const bw = Math.min(W * .6, 380), bx = W / 2 - bw / 2, by = H / 2 + 10, bh = 16;
    const maxRazao = 3 * this.nc + 1;     // referência: combustão completa
    ctx.save();
    ctx.fillStyle = cssVar('--bg-panel2', '#101c2b');
    kRound(ctx, bx, by, bw, bh, 8); ctx.fill();
    ctx.fillStyle = this.tipo.dot;
    kRound(ctx, bx, by, bw * clamp(e.razaoO2 / maxRazao, 0, 1), bh, 8); ctx.fill();
    ctx.strokeStyle = cssVar('--border', '#1c2e44'); ctx.lineWidth = 1;
    kRound(ctx, bx, by, bw, bh, 8); ctx.stroke();
    ctx.restore();
    kLabel(ctx, `O₂ por molécula de combustível: ${fmt(e.razaoO2, 2)}`, W / 2, by + bh + 20,
      { size: 11, align: 'center', color: cssVar('--accent-amber', '#fbbf24') });

    const chips = [
      [`${e.alcano}`, cssVar('--scene-b', '#94a3b8')],
      [`${e.carbonado} ${e.produto}`, this.tipo.dot],
      [`${e.agua} H₂O`, cssVar('--accent-alt', '#38bdf8')],
    ];
    chips.forEach((c, i) => kChip(ctx, c[0], W * (.24 + .26 * i), H - 56, { size: 12, fg: c[1], border: c[1] }));
    kLabel(ctx, this.tipo.nota, W / 2, H - 20, { size: 10, align: 'center', color: cssVar('--text-muted', '#3d566e') });
  }

  /* ══════════ resultados ══════════ */
  getResults() {
    if (this.modo === 'adicao') {
      const a = this.adicao;
      return [
        { l: 'Reação', v: a.nome },
        { l: 'Tipo', v: 'adição à ligação dupla' },
        { l: 'Reagente', v: a.reagente },
        { l: 'Catalisador', v: a.catalisador },
        { l: 'Produto', v: a.produto, cls: 'val-ok' },
        { l: 'Equação', v: a.eq },
        { l: 'Regra', v: a.regra },
      ];
    }
    if (this.modo === 'substituicao') {
      const s = this.subst;
      return [
        { l: 'Reação', v: s.nome },
        { l: 'Tipo', v: 'substituição' },
        { l: 'Substrato', v: s.substrato },
        { l: 'Reagente', v: s.reagente },
        { l: 'Condição', v: s.condicao },
        { l: 'Mecanismo', v: s.mecanismo },
        { l: 'Produtos', v: s.produto, cls: 'val-ok' },
        { l: 'Equação', v: s.eq },
      ];
    }
    const e = this._equacao();
    return [
      { l: 'Alcano', v: e.alcano },
      { l: 'Carbonos', v: String(e.n) },
      { l: 'Hidrogênios', v: String(e.H) },
      { l: 'Tipo de combustão', v: this.tipo.nome },
      { l: 'Equação balanceada', v: e.texto, cls: 'val-ok' },
      { l: 'Mols de O₂ por mol de alcano', v: fmt(e.razaoO2, 2), cls: 'val-alt' },
      { l: 'Produto carbonado', v: `${e.carbonado} ${e.produto}` },
      { l: 'Água formada', v: `${e.agua} H₂O` },
    ];
  }

  getOverlay() {
    if (this.modo === 'adicao') return `Adição · ${this.adicao.reagente}`;
    if (this.modo === 'substituicao') return `Substituição · ${this.subst.reagente}`;
    return `Combustão ${this.tipo.nome} · ${this._equacao().alcano}`;
  }
}

// ══════════════════════════════════════════════════════════════════
// APP — casco genérico da família de simuladores.
// Acordeões, Alt+1–N, Enter/Espaço no canvas, gaveta mobile,
// resultados ao vivo. A mecânica específica vive na classe Mech.
// ══════════════════════════════════════════════════════════════════
/** Preenche uma .opt-grid com botões a partir de itens dos dados. */
